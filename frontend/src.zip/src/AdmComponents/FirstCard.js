import './FirstCard.css';
function FirstCard(){
    return(
        <div className="first-card">
            <div className='First-card-top'>
                   <h2>78453</h2>
                </div>
                <p>Viso vartotoju</p>
        </div>
    );

}
export default FirstCard;