function Categories() {
  return (
    <>
      <h1>categories</h1>
    </>

  );
}
export default Categories;