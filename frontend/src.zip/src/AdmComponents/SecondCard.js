import './SecondCard.css';
function SecondCard(){
    return(
        <div className="second-card">
            <div className='second-card-top'>
                   <h2>4598</h2>
                </div>
                <p>Viso regi. ivykiu</p>
        </div>
    );

}
export default SecondCard;