import './ThirdCard.css';
function ThirdCard(){
    return(
        <div className="third-card">
            <div className='third-card-top'>
                   <h5>Pop. islaid kategorija</h5>
                </div>
                <p>Kazkas </p>
        </div>
    );

}
export default ThirdCard;