//import ReactDOM from 'react-dom';
//import './index.css';
//import reportWebVitals from './reportWebVitals';
//mport {BrowserRouter } from "react-router-dom";
//import MyRoutes from './MyRoutes';

//ReactDOM.render(
//  <BrowserRouter>
//   <MyRoutes />
//  </BrowserRouter>,
//  document.getElementById('root')
//);


//reportWebVitals();