export var exVar = {
  IS_NEW_EARNING: true,
}